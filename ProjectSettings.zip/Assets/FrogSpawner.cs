using UnityEngine;

public class FrogSpawner : MonoBehaviour
{
    public GameObject frogPrefab; // Drag the frog prefab here
    public float spawnInterval = 2.0f; // Time delay between spawns

    // Screen area range for frog placements
    public float minX = -6f;
    public float maxX = 6f;
    public float minY = -3f;
    public float maxY = 3f;

    void Start()
    {
        // Calls the "SpawnFrog" method repeatedly based on your timer interval
        InvokeRepeating("SpawnFrog", 1.0f, spawnInterval);
    }

    void SpawnFrog()
    {
        // Choose a random position inside the screen limits
        float randomX = Random.Range(minX, maxX);
        float randomY = Random.Range(minY, maxY);
        Vector3 randomPosition = new Vector3(randomX, randomY, 0f);

        // Instantiate creates a brand new copy of the prefab at that spot
        Instantiate(frogPrefab, randomPosition, Quaternion.identity);
    }
}