using UnityEngine;

public class FrogBehaviour : MonoBehaviour
{
    [Header("Frog Settings")]
    public float lifetime = 2.5f; // Time before it vanishes if missed

    void Start()
    {
        // Automatically destroys the frog if the player is too slow
        Destroy(gameObject, lifetime);
    }

    // This built-in Unity function runs automatically when clicked
    void OnMouseDown()
    {
        // Instantly clears this specific frog off the screen
        Destroy(gameObject);
    }
}