using UnityEngine;
using TMPro;

public class scale : MonoBehaviour
{
    public static int score = 0;
    public TextMeshProUGUI scoreText;
    
    public void OnMouseDown()
    {
        score += 10;
        if (scoreText != null)
            scoreText.text = "Score: " + score;
        Destroy(gameObject);
    }
}